package persistence;

import java.io.IOException;
import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface RegistroHawkins<T extends Serializable> {

    void agregar(T elem);
    T obtener(int index);
    T eliminar(int index);

    List<T> filtrar(Predicate<T> f);

    void ordenar();
    void ordenar(Comparator<T> comp);

    void paraCadaElemento(Consumer<T> c);

    void guardarEnArchivo(String path) 
            throws IOException;
    void cargarDesdeArchivo(String path) 
            throws IOException, ClassNotFoundException;

    void guardarEnCSV(String path) 
            throws IOException;
    void cargarDesdeCSV(String path, Function<String,T> creador) 
            throws IOException;
}
