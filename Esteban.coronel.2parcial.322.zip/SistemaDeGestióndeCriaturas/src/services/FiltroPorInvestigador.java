package services;

import model.CasoHawkins;

public class FiltroPorInvestigador implements FiltroCaso {

    private String investigador;

    public FiltroPorInvestigador(String investigador) {
        this.investigador = investigador;
    }

    @Override
    public boolean filtrar(CasoHawkins c) {
        return c.getInvestigador().equalsIgnoreCase(investigador);
    }
}
