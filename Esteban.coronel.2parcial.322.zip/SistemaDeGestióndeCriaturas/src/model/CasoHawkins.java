package model;

import java.io.Serializable;

public class CasoHawkins implements CSVSerializable, Comparable<CasoHawkins>, Serializable {

    private int id;
    private String titulo;
    private String investigador;
    private ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }
    public int getId() { 
        return id; 
    }
    public String getTitulo() { return titulo;
    }
    public String getInvestigador() { 
        return investigador; 
    }
    public ClasificacionCaso getClasificacion() {
        return clasificacion; 
    }

    @Override
    public int compareTo(CasoHawkins o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + investigador + "," + clasificacion;
    }

    public static CasoHawkins fromCSV(String linea) {
        String[] p = linea.split(",");
        return new CasoHawkins(Integer.parseInt(p[0]),p[1],p[2],ClasificacionCaso.valueOf(p[3])
        );
    }

    @Override
    public String toString() {
        return id + " - " + titulo + " - " + investigador + " - " + clasificacion;
    }
}
