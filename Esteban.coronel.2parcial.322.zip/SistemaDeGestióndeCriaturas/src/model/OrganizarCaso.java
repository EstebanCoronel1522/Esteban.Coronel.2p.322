package model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import services.FiltroCaso;

public class OrganizarCaso {

    public static List<CasoHawkins> filtrarCasos(List<CasoHawkins> casos, FiltroCaso filtro) {

        List<CasoHawkins> resultado = new ArrayList<>();
        for (CasoHawkins c : casos) {
            if (filtro.filtrar(c)) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    public static void ordenarCasos(List<CasoHawkins> lista, Comparator<CasoHawkins> criterio) {
        lista.sort(criterio);
    }
}
