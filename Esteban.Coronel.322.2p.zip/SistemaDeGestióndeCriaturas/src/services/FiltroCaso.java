package services;

import model.CasoHawkins;

@FunctionalInterface
public interface FiltroCaso {
    boolean filtrar(CasoHawkins c);
}
