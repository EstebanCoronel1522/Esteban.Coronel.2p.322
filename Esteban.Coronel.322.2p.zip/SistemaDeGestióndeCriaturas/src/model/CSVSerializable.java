package model;

public interface CSVSerializable {
    String toCSV();
}
