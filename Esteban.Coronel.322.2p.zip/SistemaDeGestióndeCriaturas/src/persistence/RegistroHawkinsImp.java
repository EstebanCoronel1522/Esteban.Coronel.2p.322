package persistence;

import static config.RutaArchivos.getRutaCSVString;
import java.io.*;
import java.util.*;
import java.util.function.*;

public class RegistroHawkinsImp<T extends Serializable> implements RegistroHawkins<T> {

    private final List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T elem) { 
        lista.add(elem); 
    }

    @Override
    public T obtener(int index) { 
        return lista.get(index); 
    }

    @Override
    public T eliminar(int index) { 
        return lista.remove(index); 
    }

    @Override
    public List<T> filtrar(Predicate<T> f) {
        List<T> r = new ArrayList<>();
        for (T t : lista) 
        if (f.test(t)) r.add(t);
        return r;
    }

    @Override
    public void ordenar() {
        Collections.sort((List) lista);
    }

    @Override
    public void ordenar(Comparator<T> comp) {
        lista.sort(comp);
    }
    
    @Override
    public void paraCadaElemento(Consumer<T> c) {
        lista.forEach(c);
    }
    

    @Override
    public void guardarEnArchivo(String path) throws IOException {
        File carpeta = new File(config.RutaArchivos.BASE);
        if (!carpeta.exists()) carpeta.mkdirs();
        try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(path))) {
            o.writeObject(lista);
        }
    }

    @Override
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream o = new ObjectInputStream(new FileInputStream(path))) {
            List<T> cargada = (List<T>) o.readObject();
            lista.clear();
            lista.addAll(cargada);
        }
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
         File carpeta = new File(config.RutaArchivos.BASE);
         if (!carpeta.exists()) carpeta.mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (T elem : lista) {
                bw.write(((model.CSVSerializable) elem).toCSV());
                bw.newLine();
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> creador)
            throws IOException {

        lista.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(getRutaCSVString()))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    lista.add(creador.apply(linea));
                }
            }
        }
    }
}
